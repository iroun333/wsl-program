package com.example.poagethpeerconnectapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.util.Log;
import org.ethereum.geth.*;

import java.io.IOException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
//import android.content.res.AssetManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        setTitle("Android In-Process Node");
        final TextView textbox = (TextView) findViewById(R.id.textbox);

        //AssetManager assetManager = this.getAssets();
        byte[] buffer1;
        try (InputStream is1 = this.getAssets().open("static-nodes.json")) {
            //try (InputStream is = assetManager.open("static-nodes.json")) {
            int size = 0;
            try {
                size = is1.available();
            } catch (IOException e) {
                e.printStackTrace();
            }
            buffer1 = new byte[size];
            is1.read(buffer1);
            is1.close();
            String staticNodesJson = new String(buffer1, "UTF-8");
            textbox.append(staticNodesJson + "\n");

            File dir = new File(getFilesDir() + "/.ethereum/GethDroid/");
            if (dir.exists() == false) {
                dir.mkdirs();

                Log.d("GETH", "mkdirs" + dir.getAbsolutePath());
            }
            File f = new File(dir, "static-nodes.json");
            if (f.exists() == false) {
                f.createNewFile();
                Log.d("GETH", "create new file" + f.getAbsolutePath());
            }

            copyString(staticNodesJson, f);
            Log.d("GETH", "finished copy");

        } catch (IOException e) {
            e.printStackTrace();
        }
/*
        //AssetManager assetManager = this.getAssets();
        byte[] buffer1;
        try (InputStream is1 = this.getAssets().open("static-nodes.json")) {
        //try (InputStream is = assetManager.open("static-nodes.json")) {
            int size = 0;
            try {
                size = is1.available();
            } catch (IOException e) {
                e.printStackTrace();
            }
            buffer1 = new byte[size];
            is1.read(buffer1);
            is1.close();
            String staticNodesJson = new String(buffer1, "UTF-8");
            textbox.append(staticNodesJson + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
 */

        Context ctx = new Context();
        Log.d("GETH", getFilesDir() + "/.ethereum");
        byte[] buffer2;
        try (InputStream is2 = this.getAssets().open("poa_net.json")) {
            int size = 0;
            try {
                size = is2.available();
            } catch (IOException e) {
                e.printStackTrace();
            }
            buffer1 = new byte[size];
            is2.read(buffer1);
            is2.close();
            String genesisJson = new String(buffer1, "UTF-8");
            //textbox.append(genesisJson + "\n");

            NodeConfig nodeConfig ;
            nodeConfig  = Geth.newNodeConfig();
            nodeConfig.setEthereumGenesis(genesisJson);
            nodeConfig.setEthereumEnabled(true);
            //nodeConfig.setEthereumGenesis(Geth.testnetGenesis());
            nodeConfig.setEthereumNetworkID(20);
            Node node = Geth.newNode(getFilesDir() + "/.ethereum", nodeConfig );
            node.start();

            NodeInfo info = node.getNodeInfo();
            textbox.append("My name: " + info.getName() + "\n");
            textbox.append("My address: " + info.getListenerAddress() + "\n");
            textbox.append("My protocols: " + info.getProtocols() + "\n\n");

            EthereumClient ec = node.getEthereumClient();
            textbox.append("Latest block: " + ec.getBlockByNumber(ctx, -1).getNumber() + ", syncing...\n");

            NewHeadHandler handler = new NewHeadHandler() {
                @Override public void onError(String error) { }
                @Override public void onNewHead(final Header header) {
                    MainActivity.this.runOnUiThread(new Runnable() {
                        public void run() { textbox.append("#" + header.getNumber() + ": " + header.getHash().getHex().substring(0, 10) + "…\n"); }
                    });
                }
            };
            ec.subscribeNewHead(ctx, handler,  16);
        } catch (Exception e) {
            e.printStackTrace();
        }

        /*
            Node node = Geth.newNode(getFilesDir() + "/.ethereum", new NodeConfig());

            node.start();

            NodeInfo info = node.getNodeInfo();
            textbox.append("My name: " + info.getName() + "\n");
            textbox.append("My address: " + info.getListenerAddress() + "\n");
            textbox.append("My protocols: " + info.getProtocols() + "\n\n");

            EthereumClient ec = node.getEthereumClient();
            textbox.append("Latest block: " + ec.getBlockByNumber(ctx, -1).getNumber() + ", syncing...\n");

            NewHeadHandler handler = new NewHeadHandler() {
                @Override public void onError(String error) { }
                @Override public void onNewHead(final Header header) {
                    MainActivity.this.runOnUiThread(new Runnable() {
                        public void run() { textbox.append("#" + header.getNumber() + ": " + header.getHash().getHex().substring(0, 10) + "…\n"); }
                    });
                }
            };
            ec.subscribeNewHead(ctx, handler,  16);
        } catch (Exception e) {
            e.printStackTrace();
        }
 */

/*
        Context ctx = new Context();
        Log.d("GETH", getFilesDir() + "/.ethereum");
        try {
            Node node = Geth.newNode(getFilesDir() + "/.ethereum", new NodeConfig());

            node.start();

            NodeInfo info = node.getNodeInfo();
            textbox.append("My name: " + info.getName() + "\n");
            textbox.append("My address: " + info.getListenerAddress() + "\n");
            textbox.append("My protocols: " + info.getProtocols() + "\n\n");

            EthereumClient ec = node.getEthereumClient();
            textbox.append("Latest block: " + ec.getBlockByNumber(ctx, -1).getNumber() + ", syncing...\n");

            NewHeadHandler handler = new NewHeadHandler() {
                @Override public void onError(String error) { }
                @Override public void onNewHead(final Header header) {
                    MainActivity.this.runOnUiThread(new Runnable() {
                        public void run() { textbox.append("#" + header.getNumber() + ": " + header.getHash().getHex().substring(0, 10) + "…\n"); }
                    });
                }
            };
            ec.subscribeNewHead(ctx, handler,  16);
        } catch (Exception e) {
            e.printStackTrace();
        }
 */
    }

    private void copyString(String fileContents, File outputFile) throws FileNotFoundException {
            OutputStream output = new FileOutputStream(outputFile);
            PrintWriter p = new PrintWriter(output);
            p.println(fileContents);
            p.flush();
            p.close();
    }

}
