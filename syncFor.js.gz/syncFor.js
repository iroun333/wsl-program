const async = require('async');
const fs = require('fs');
const util = require('util')

    var objList = [];
    var objWorkList = [];

    main();

async function main() {
        var obj = {};
        let i = 0;
        await fsdummy1(1);
        await fsdummy2(2);
        objWorkList = await setObj();
        async.each(objWorkList, function(objWork, callback){
            objPush(objWork, i);
            i++;
            callback();
        }, function(err){
            if(err) throw err;
        });

        await printObj();
}

async function printObj() {
    console.log("objList.length=" + objList.length);
    async.each(objList, function(obj, callback){
        console.log("obj.txData.txHash= " + obj.txData.txHash);
        //console.log(util.inspect(obj,false,null));
        callback();
    }, function(err){
        if(err) throw err;
    });
}

async function objPush(obj, i){
            obj.txData.txHash = String(i) + String(i) + String(i) + String(i);
            //obj["txHash"] = "0000";
            objList.push({"txData": obj.txData});
            //console.log(obj.txHash);

}

async function setObj() {
    var objList = [];
    var obj = {};
    asyncFor(10, function(loop) {
        obj["txHash"] = "0000";
        objList.push({"txData": obj});
        //console.log(objList.txData.txHash);
        obj = {};
        loop.next();
    },
    function(){
    });
    return objList;
}

function asyncFor(iterations, func, callback) {
    var index = 0;
    var done = false;
    var loop = {
        next: function() {
            if (done) {
                return;
            }

            if (index < iterations) {
                index++;
                func(loop);

            } else {
                done = true;
                callback();
            }
        },

        iteration: function() {
            return index - 1;
        },

        break: function() {
            done = true;
            callback();
        }
    };
    loop.next();
    return loop;
}

async function fsdummy1(value) {
    return new Promise(function(resolve, reject){
        fs.readFile("syncFor.js", "utf-8", function(err, data) {
            if(err) throw err;
            console.log("value1=", value);
            resolve();
        });
    });
}

async function fsdummy2(value) {
    return new Promise(function(resolve, reject){
        fs.readFile("syncFor.js", "utf-8", function(err, data) {
            if(err) throw err;
            console.log("value1=", value);
            resolve();
        });
    });
}

